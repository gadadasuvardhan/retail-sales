# Retail Power BI - rebuilt project

## Open this version
1. Extract the entire ZIP into a NEW folder. Do not merge it into the earlier project.
2. Open Retail.pbip from the newly extracted folder.
3. Select Home > Refresh (or Refresh now on the banner). The embedded Orders source needs no file path or sign-in.
4. After refresh, open Order details. Loaded rows should be 9,994 and Orders should be 5,009. Overview should show Sales $2,297,200.86, Profit $286,397.02, and Profit Margin 12.47% with no slicer selections.
5. Save As .pbix if required for submission.

The initial incomplete/no-data banner can appear because PBIP source projects do not include a preloaded data cache. It should clear after successful refresh. Do not interpret embedded query data as already loaded into the Desktop model.

## What changed
- Corrected the enhanced report content version to 2.0.0. The .pbir wrapper remains version 4.0; these versions describe different things.
- Added a bundled Microsoft base theme and its resource registration.
- Added Report and SemanticModel platform metadata.
- Added an Order details page with row-count controls and an order-line table.
- Preserved the original 9,994 records and all 24 columns.

## Verification
Report definition JSON validated against Microsoft schemas. Page/visual files and model references checked. Embedded data decompressed and reconciled against the original totals. Native Power BI Desktop opening, refresh and visual rendering were not verified here; this package is a repaired PBIP, not a verified preloaded PBIX.

If Refresh reports an error, retain the full error text. A standalone Orders_Embedded.pq contains the same path-free source for Power Query Advanced Editor. The cleaned CSV is also included for a direct Text/CSV import if needed.

References:
https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-dataset
https://github.com/microsoft/BCApps/blob/main/src/Apps/W1/PowerBIReports/Power%20BI%20Files/Projects%20app/Projects%20app.Report/definition/version.json
