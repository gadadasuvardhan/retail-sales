-- SQLite dialect. Grain: one order line. Money assumed USD.

-- 01_kpis
SELECT COUNT(*) AS order_lines, COUNT(DISTINCT order_id) AS orders, SUM(sales) AS sales, SUM(profit) AS profit, SUM(profit)/NULLIF(SUM(sales),0) AS profit_ratio FROM orders;

-- 02_regions
SELECT region, SUM(sales) AS sales, SUM(profit) AS profit, SUM(profit)/NULLIF(SUM(sales),0) AS profit_ratio FROM orders GROUP BY region ORDER BY sales DESC;

-- 03_categories
SELECT category, SUM(sales) AS sales, SUM(profit) AS profit FROM orders GROUP BY category ORDER BY profit DESC;

-- 04_loss_categories
SELECT category, SUM(profit) AS profit FROM orders GROUP BY category HAVING SUM(profit)<0 ORDER BY profit;

-- 05_loss_subcategories
SELECT category, sub_category, SUM(sales) AS sales, SUM(profit) AS profit FROM orders GROUP BY category,sub_category HAVING SUM(profit)<0 ORDER BY profit;

-- 06_monthly_trend
SELECT substr(order_date,1,7) AS month, SUM(sales) AS sales, SUM(profit) AS profit FROM orders GROUP BY month ORDER BY month;

-- 07_discount
SELECT discount, COUNT(*) AS lines, SUM(sales) AS sales, SUM(profit) AS profit, SUM(profit)/NULLIF(SUM(sales),0) AS profit_ratio FROM orders GROUP BY discount ORDER BY discount;

-- 08_top_products
SELECT product_id, product_name, SUM(sales) AS sales, SUM(profit) AS profit FROM orders GROUP BY product_id,product_name ORDER BY sales DESC LIMIT 10;

-- 09_delivery
SELECT ship_mode, AVG(delivery_days) AS avg_order_to_ship_days FROM orders GROUP BY ship_mode;

-- 10_integrity
SELECT COUNT(*)-COUNT(DISTINCT row_id) AS duplicate_row_ids, SUM(CASE WHEN ship_date<order_date THEN 1 ELSE 0 END) AS negative_shipping_intervals FROM orders;