from pathlib import Path
import sqlite3
import pandas as pd
base=Path(__file__).resolve().parents[1]
df=pd.read_csv(base/'data/superstore_clean.csv',dtype={'Postal Code':str})
df.columns=[c.lower().replace(' ','_').replace('-','_') for c in df.columns]
with sqlite3.connect(base/'sql/retail.db') as conn:
    df.to_sql('orders',conn,if_exists='replace',index=False)
print('Imported',len(df),'order lines')
